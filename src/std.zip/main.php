<?PHP
/**
* @package %appname%
* @name %filename%
* %description%
* @Author %author% < %email% >
* @link %link%
* @Version 0.1 started %date%
* modified %date%
**/
class %classname% extends appPlugins {

    private $params = array();
    static $home = '';
    const ME = '%lowclassname%';
    const TABLE_ONE = 'mytable'; # private tables names here...
    const RIGHTNAME = '%plg_rights%';

    function __construct() {
        self::$home = appEnv::$FOLDER_ROOT . appEnv::FOLDER_PLUGINS . '%my_folder%';
    }

    public function modify_mainmenu() {
        $submenu = array();
        appEnv::addTplFolder(self::$home);
        $userlev = appEnv::$auth->getAccessLevel(self::RIGHTNAME);
        if ( $userlev ) {

            appEnv::addSubmenuItem('inputdata', '%lowclassname%_some_action', appEnv::getLocalized('%lowclassname%:some_action'),'./?plg='.self::ME.'&action=some_action');
            if ( $userlev >= 10 ) {
                $submenu = array(
                    'mnu_list_products' => array('title'=>appEnv::getLocalized('%lowclassname%:list_prodcodes'), 'href'=>'./?plg='.self::ME.'&action=list_prodcodes')
                   ,'mnu_list_depts'    => array('title'=>appEnv::getLocalized('%lowclassname%:list_depts'), 'href'=>'./?plg='.self::ME.'&action=list_depts')
                );
                appEnv::addSubmenuItem('mnu_admin', 'agt_agreem_admin', appEnv::getLocalized('%lowclassname%:main_title').'...','',   false, $submenu);
            }
        }
    }

    public function stub() {

        $userlev = appEnv::$auth->getAccessLevel(self::RIGHTNAME);

        if($userlev>0) {
          $code = "<a href=\"./?plg=".self::ME.'&action=some_action">' . appEnv::getLocalized('%lowclassname%:some_action') . '</a>';
          appEnv::drawUserBlock($code, '%lowclassname%:main_title');
       }
    }

    public function dispatch($params=false) {
        $action = isset($params['action']) ? $params['action'] : '';
        if (method_exists($this, $action)) $this->$action;

#IF plg_createbkend
        else {
            include_once(self::$home . 'backend.php');
            if(!$params) {
                $params = decodePostData(true);
            }

            $plg_backend = new %classname%Backend($params);


            if(method_exists($plg_backend, $action)) $plg_backend->$action();
            elseif (method_exists($plg_backend, 'dispatch')) $plg_backend->dispatch();
            else die('%classname%Backend : Unknown action for '.self::ME.' : '.$action);
        }
#ELSE
        else die('%classname% : Unknown action for '.self::ME.' : '.$action);
#ENDIF
    }
} # %classname% class end

appEnv::registerPlugin('%lowclassname%');