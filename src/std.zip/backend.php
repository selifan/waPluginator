<?PHP
/**
* @package %appname%
* @name %filename%
* %description%
* Backend module (all functionality here !)
* @Author %author% < %email% >
* @link %link%
* @Version 0.1 started %date%
* modified %date%
**/
class %classname%Backend {

    const RIGHTNAMES = '%plg_rights%';

    static $debug = 0;
    static $_prodid = '';
    private $err = array();
    private static $home = ''; // plugin files subfolder
    private $_worksheet = null;

    public function __construct($params = false) {
        if(is_array($params)) $this->_p = $params;
        else $this->_p = DecodePostData(1);
        self::$home = %classname%::$home; // appEnv::FOLDER_PLUGINS . '%my_folder%';
    }

    public function some_action() {
        appEnv::drawPageHeader('some_action');
        echo "some_action main body !";
        appEnv::drawPageBottom();
        exit;
    }

    # some AJAX request handler template
    public function ajax_get_nnn() {

        $prodcode = isset($this->_p['nnn']) ? $this->_p['nnn'] : 0;
        $ret = '1';
        # ... your actions here
        exit (EncodeResponseData($ret));
    }

} // %classname%Backend end
