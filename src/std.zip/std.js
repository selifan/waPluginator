/**
* @package %appname%
* @name %filename%
* javascript code for %classname% plugin
* @Author %author% < %email% >
* @link %link%
* @Version 0.1 started %date%
* modified %date%
**/
%classname% = {
  backend: "./?plg=%classname%"
  sendRequest: function() {
     var params = {action:'getsomething',id:0 };
     $.post(this.backend, params, function(data) {
        $('#div_%classname%").html(data);
     });
  }
};